package com.manthan.test.array.tst;

public class Demo {
	void eat(int[] a)
	{
		for(int k:a)
		{
			System.out.println(k);
		}
	}
	
	double[] getMe()
	{
		double r[]= {1.2,4.5,8};
		return r;
	}
}
