package com.manthan.test.array.tst;

public class TestA {

	public static void main(String[] args) {
			int a[]=new int[4];
			
			double b[]=new double[6];
			a[0]=1;
			a[1]=2;
			a[2]=6;
			a[3]=3;
			
			b[0]=3.9;
			b[4]=8.6;
			
			
			for(int i=0;i<a.length;i++) {
				
			
			System.out.println(a[i]);}
			
			for(int i=0;i<b.length;i++) {
				
				
				System.out.println(b[i]);}
	}

}
