package com.manthan.test.array.tst;

public class TestE {
	public static void main(String[] args) {
		
	
	
	int x[]= {1,2,3,4};
	Demo d=new Demo();
	d.eat(x);
	}

}
