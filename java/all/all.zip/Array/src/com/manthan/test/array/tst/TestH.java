package com.manthan.test.array.tst;

public class TestH {

	public static void main(String[] args) {
		Demo d = new Demo();
		double[] s=d.getMe();
		
		
	}

}
