package com.manthan.test.array.tst;

public class TestK {

	public static void main(String[] args) {
		int i=5;
		Integer k=i;
		System.out.println(k);
		
		
		Integer m=new Integer(77);
		int t=m;
		
		
		
		
		
		
		String q="90";
		String p="70";
		System.out.println(p+q);
	}

}
