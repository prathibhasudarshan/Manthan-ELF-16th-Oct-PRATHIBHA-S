package com.manthan.test.array.tst;

public class Testd {
	public static void main(String[] args) {
		double[] d= {10.7,9.8,8.6};
		
		String[] s= {"tttt","yyyy","iiii"};
		for(double y: d)
		{
			System.out.println(y);
		}
		
		for(String i: s)
		{
			System.out.println(i);
		}
	}

}
