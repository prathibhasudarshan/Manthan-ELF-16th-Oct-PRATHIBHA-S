package com.manthan.test.array.tst;

public class Testm {

	public static void main(String[] args) {
		String q="2.4";
		String p="70";
		
		String t="90";
		
		System.out.println(p+q);
		
		
		double i=Integer.parseInt(q);
		System.out.println(i);
		
		System.out.println(Double.parseDouble(t));
		int j=Integer.parseInt(p);
		System.out.println(j);
		
		//System.out.println(i+j);
	
	}

}
