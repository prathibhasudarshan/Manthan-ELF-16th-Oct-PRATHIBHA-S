package com.manthan.Collect.list;

import java.util.LinkedHashMap;

public class H {
	public static void main(String[] args) {
		LinkedHashMap<Character,String> hs=new LinkedHashMap<Character,String>();
		hs.put('M', "pppp");
		hs.put('A', "rrr");
		hs.put('B', "aaa");
		hs.put('s', "ssss");

	}

}
