package com.manthan.Collect.list;

public class StudentMap {

}
