package com.manthan.Collection;

import java.util.ArrayList;

public class E {

	public static void main(String[] args) {
		ArrayList al=new ArrayList();
		al.add(5);
		al.add(8);
		al.add('f');
		al.add("simra");
		
		System.out.println(al);
	}

}
