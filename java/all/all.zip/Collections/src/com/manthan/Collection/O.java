package com.manthan.Collection;

import java.util.LinkedList;

public class O {

	public static void main(String[] args) {
		LinkedList<String> ll = new LinkedList<String>();
		ll.add("uuu");
		ll.add("oo");
		ll.add("yyy");
		for(String y:ll)
		{
			System.out.println(y);
		}
	}

}
