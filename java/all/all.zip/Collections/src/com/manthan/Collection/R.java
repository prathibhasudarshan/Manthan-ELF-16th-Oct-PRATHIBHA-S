package com.manthan.Collection;

import java.util.ArrayList;

public class R {

	public static void main(String[] args) {
		ArrayList<Double> a = new ArrayList<Double>();
		a.add(5.1);
		a.add(6.2);
		a.add(3.6);
		a.add(4.6);
		a.add(2.3);
		
		
		System.out.println();
	}

}
