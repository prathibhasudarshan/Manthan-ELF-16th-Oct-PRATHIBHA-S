package com.manthan.Overloading;

public class Computer {
	public void run() {
		
		System.out.println(" running");
		
	}

}
