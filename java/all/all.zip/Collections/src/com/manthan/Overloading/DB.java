package com.manthan.Overloading;

public class DB {
	void save(Student s)
	{
		System.out.println("saving");
		System.out.println("id is"+s.getID());
	}

}
