package com.manthan.Overloading;

public class Data {
	
	

}
