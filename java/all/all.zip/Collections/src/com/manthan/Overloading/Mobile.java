package com.manthan.Overloading;

public class Mobile {
	int cost;
	void call()
	{
		System.out.println(" can call");
	}

}
