package com.manthan.Overloading;

public class Person { 
	int age;
	
	Mobile m=new Mobile();
	void walk()
	{
		System.out.println(" has a walk");
	}

}
