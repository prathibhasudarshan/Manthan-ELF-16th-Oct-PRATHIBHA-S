package com.manthan.Overloading;

public class Room {
	static int cost;
	final static Computer c=new Computer();
	void on()
	{
		System.out.println("running");
	}

}
