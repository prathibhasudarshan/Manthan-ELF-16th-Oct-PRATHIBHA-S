package com.manthan.Overloading;

import java.io.Serializable;

public class Student implements Serializable {
	
	private int id;
	public void setID(int id)
	{
		this.id=id;
	}
	public int getID() {
		return id;
		
	}
}
