package com.manthan.Overloading;

public class TestA {

	public static void main(String[] args) {
		Train t = new Train();
		t.search(7777);
	}

}
