package com.manthan.Overloading;

public class TestD {

	public static void main(String[] args) {
		
		Computer c=new Computer();		
		Room.cost=788;
		Room.c.run();
		c.run();
		
		System.out.println( 
				);
	}

}
