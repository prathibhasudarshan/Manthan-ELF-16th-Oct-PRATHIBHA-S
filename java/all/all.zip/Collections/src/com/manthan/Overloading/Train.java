package com.manthan.Overloading;

public class Train {
	
	void search(String name)
	{
		System.out.println(" by name"+name);
	}
	
	void search(int num)
	{
		System.out.println("by num"+num);
	}

}
