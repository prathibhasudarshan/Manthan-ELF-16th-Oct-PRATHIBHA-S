package com.manthan.lamda;

public interface Fact {
	int fact(int a);
}
