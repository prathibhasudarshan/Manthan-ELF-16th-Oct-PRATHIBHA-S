package com.manthan.lamda;

public interface Pen {
	int add(int a,int b);
	

}
