
public class Animall {
	int cost;
	void run()
	{
		System.out.println("i m run");
	}

}
