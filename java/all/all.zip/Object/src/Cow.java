
public class Cow extends Animall {
	int size;
	void eat()
	{
		System.out.println(" i m eat");
	}
	

}
