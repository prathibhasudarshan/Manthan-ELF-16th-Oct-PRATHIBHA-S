package com.manthan.Thread;

public class A {
	public static void main(String[] args) {
		MyTask m=new MyTask();
		m.start();
		
	}
	
}
