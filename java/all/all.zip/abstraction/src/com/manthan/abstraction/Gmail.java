package com.manthan.abstraction;

public class Gmail extends Google 
{

	@Override
	void shareFile() {
		System.out.println("");
	}
	

}
                                                             
