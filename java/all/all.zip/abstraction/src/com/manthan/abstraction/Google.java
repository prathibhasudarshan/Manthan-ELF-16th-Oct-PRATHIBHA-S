package com.manthan.abstraction;

public abstract class Google
{
	void verify()
	{
		System.out.println("verified account");
	}
	abstract void shareFile();
	

}
