package com.manthan.abstraction;

public class Stringclass {

	public static void main(String[] args) {
		String s="ppp";
		int i=s.length();
		System.out.println(i);
	}

}
