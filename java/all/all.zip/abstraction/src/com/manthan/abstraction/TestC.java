package com.manthan.abstraction;

public class TestC {
	public static void main(String[] args) {
		String u="dimple";
		String y=u.toUpperCase();
		System.out.println(y);
		int m=u.length();
		System.out.println(m);}

}
