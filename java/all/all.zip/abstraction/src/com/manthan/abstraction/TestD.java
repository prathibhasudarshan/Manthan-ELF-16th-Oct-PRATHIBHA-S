package com.manthan.abstraction;

public class TestD {

	public static void main(String[] args) {
		StringBuffer buffer=new StringBuffer("RAJU");
		StringBuffer b = new StringBuffer();
		
	b.append(b);
	System.out.println(b);}

}
