package com.manthan.abstraction;

public class Testf {
	public static void main(String[] args) {
		Student s = new Student("priya", 2);
		System.out.println(s.getName());
		System.out.println(s.getId());
	}

}
