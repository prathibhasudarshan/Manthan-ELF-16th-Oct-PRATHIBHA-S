package com.manthan.exception.test;

import java.io.IOException;

public class TestI {

	public static void main(String[] args) {
		Demo d = new Demo();


	}

}
