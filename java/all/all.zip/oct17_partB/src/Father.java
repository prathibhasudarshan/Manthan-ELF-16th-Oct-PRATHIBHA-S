
public class Father 
{
	void bike()
	{
		System.out.println("cd100");
	}

}
