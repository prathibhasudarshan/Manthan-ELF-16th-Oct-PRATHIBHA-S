
public class Marker extends Pen
{
	void color()
	{
		System.out.println("black");
	}
	
	void write()
	{
		System.out.println(" on board");
	}
}
