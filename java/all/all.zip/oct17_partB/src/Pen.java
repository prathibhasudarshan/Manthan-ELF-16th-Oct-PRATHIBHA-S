
public class Pen
{
	int cost;
	void write()
	{
		System.out.println("on paper");
	}

}
