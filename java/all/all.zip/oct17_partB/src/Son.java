
public class Son extends Father
{
	/*void bike()
	{
		System.out.println("ktm");
	}*/

}
