
public class TestA {

	public static void main(String[] args) {
		//Father f=new Father();
		Father f=new Son();
		f.bike();

	}

}
