
public class TestB {

	public static void main(String[] args) {
		Pen p = new Marker();
		p.cost=50;
		p.write();

	}

}                                                             
