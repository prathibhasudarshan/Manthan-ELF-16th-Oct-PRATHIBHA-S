package com.manthan.oct18b;

public class Baby 
{
	void receive(IceCream i)
	{
		i.eat();
		i.open();
	}

}
