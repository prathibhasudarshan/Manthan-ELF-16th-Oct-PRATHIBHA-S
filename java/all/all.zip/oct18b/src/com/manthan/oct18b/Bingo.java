package com.manthan.oct18b;

public class Bingo extends Chips {
	void open()
	{
		System.out.println(" chips in Bingo");
	}
	void eat()
	{
		System.out.println(" chips eating in Bingo");
	}

}
