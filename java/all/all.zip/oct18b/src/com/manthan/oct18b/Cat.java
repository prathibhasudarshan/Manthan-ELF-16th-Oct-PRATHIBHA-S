package com.manthan.oct18b;

public class Cat 
{
	
	void receive(Chips c) {
		c.eat();
		c.open();
	}

}
