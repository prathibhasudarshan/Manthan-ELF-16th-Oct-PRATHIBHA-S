package com.manthan.oct18b;

public class Chips
{
	void open()
	{
		System.out.println(" chips in parent");
	}
	void eat()
	{
		System.out.println(" chips eating in parent");
	}

}
