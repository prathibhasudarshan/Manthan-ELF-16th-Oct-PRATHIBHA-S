package com.manthan.oct18b;

public class Gift
{
	String s;

	public Gift(String s) {
		this.s = s;
	}
	void open()
	{
		System.out.println(s);
	}
	
	

}
