package com.manthan.oct18b;

public class Girl
{
	void receive(Gift g)
	{
		g.open();
	}

}
