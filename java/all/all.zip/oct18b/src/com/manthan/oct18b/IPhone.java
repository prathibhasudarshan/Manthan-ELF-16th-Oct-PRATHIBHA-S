package com.manthan.oct18b;

public class IPhone extends Phone {

}
