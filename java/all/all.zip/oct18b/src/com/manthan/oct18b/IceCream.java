package com.manthan.oct18b;

public class IceCream 
{
	void open()
	{
		
	}
	void eat()
	{
		
	}
}
