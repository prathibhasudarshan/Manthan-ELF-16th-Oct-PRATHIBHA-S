package com.manthan.oct18b;

public class Kurkure extends Chips {
	void open()
	{
		System.out.println(" chips in kurkure");
	}
	void eat()
	{
		System.out.println(" chips eating in Lurkure");
	}

}
