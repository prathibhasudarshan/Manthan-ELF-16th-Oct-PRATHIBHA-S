package com.manthan.oct18b;

public class Lays extends Chips {
	void open()
	{
		System.out.println(" chips in LAYS");
	}
	void eat()
	{
		System.out.println(" chips eating in LAYS");
	}

}
