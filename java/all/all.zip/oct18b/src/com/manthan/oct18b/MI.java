package com.manthan.oct18b;

public class MI extends Phone {

}
