package com.manthan.oct18b;

public class Pen {
	void write()
	{
		
	}
	
	void open() {
		
	}

}
