package com.manthan.oct18b;

public class Person
{
	
	void receive(Pen p) {
		p.write();
		p.open();
	}

}
