package com.manthan.oct18b;

public class TestA {

	public static void main(String[] args) {
		Pen a = new Pen();
		
		Person r = new Person();
		r.receive(a);
		
		
	}

}
