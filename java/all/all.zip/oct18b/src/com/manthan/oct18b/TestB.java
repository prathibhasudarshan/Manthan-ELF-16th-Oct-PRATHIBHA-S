package com.manthan.oct18b;

public class TestB {

	public static void main(String[] args) {
		IceCream ii = new IceCream();
		Baby bb = new Baby();
		bb.receive(ii);
	}

}
