package com.manthan.oct18b;

public class TestC {

	public static void main(String[] args) {
Gift gg = new Gift("happy");
Girl ggg = new Girl();
ggg.receive(gg);
	}

}
