package com.manthan.oct18b;

public class TestE {

	public static void main(String[] args) {
		Chips c=new Chips();
		Cat cc=new Cat(l);
		
		
		
		Lays l=new Lays();
		l.eat();
		
		
	}

}
