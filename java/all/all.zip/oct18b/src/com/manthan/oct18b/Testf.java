package com.manthan.oct18b;

public class Testf 
{
	MI m=new MI();
	Pixel p=new Pixel();
	IPhone ii=new IPhone();
	
	Crush c=new Crush();
	c.receive(m);

}
