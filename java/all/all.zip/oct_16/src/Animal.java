
public class Animal
{
	void eat()
	{
		System.out.println(" i m eating");
	}

}
