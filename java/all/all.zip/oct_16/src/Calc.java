
public class Calc {
	int cost;
	void add() {
		System.out.println("add method");
		
	}
	void mul()
	{
		System.out.println("mul method");
	}

}
