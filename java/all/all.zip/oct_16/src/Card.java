
public class Card {
	int count;
	static int orgcount;
	void swipe()
	{
		count++;
		orgcount++;
	}
}

