
public class Cow {
	String name;
	void eat()
	{
		System.out.println(name+"grazes and eat");
	}

}
