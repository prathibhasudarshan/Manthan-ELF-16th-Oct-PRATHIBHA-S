
public class Demo {
	int i;
	static int j;
	void eat()
	{
		System.out.println("love eating");
		
	}
	static void run()
	{
		System.out.println("runs");
	}

}
