
public class Dog extends Animal
{
	void walk()
	{
		System.out.println(" i can walk");
	}

}
