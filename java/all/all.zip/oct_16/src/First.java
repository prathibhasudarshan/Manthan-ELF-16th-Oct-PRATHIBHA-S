
public class First 
{
	void call()
	{
		System.out.println("i can call");
	}
	void msg()
	{
		System.out.println("i can msg");
	}

}
