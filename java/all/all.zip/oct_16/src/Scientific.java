
public class Scientific extends Calc {
	void sin()
	{
		System.out.println("i m sin");
		
	}
	void cos()
	{
		System.out.println("i m cos");
	}

}
