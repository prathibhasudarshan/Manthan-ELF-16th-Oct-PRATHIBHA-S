
public class Second extends First
{
	void radio()
	{
		System.out.println(" i can play a song");
	}

}
