
public class Student {
	String name;
	int id;
	char gen;
	void disp()
	{
		System.out.println(name+"is my name");
		System.out.println(id+"is the id");
		System.out.println(gen+"is the gender");
	}
	

}
