
public class TestA {
	public static void main(String[] args) {
		Pen p = new Pen();
		p.cost=100;
		p.write();
		System.out.println("cost is"+p.cost);

	} 

}
