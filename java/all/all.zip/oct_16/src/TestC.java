
public class TestC {

	public static void main(String[] args) {
	Cow c = new Cow();
	c.name="ganga";
	c.eat();
	Cow d = new Cow();
	d.name="tunga";
	d.eat();
	System.out.println(c.name);
	System.out.println(d.name);

	}

}
