
public class TestD {

	public static void main(String[] args) {
		Student s = new Student();
		s.name="abhi";
		s.id=123;
		s.gen='m';
		s.disp();

	}

}
