
public class TestE {

	public static void main(String[] args) {
		Demo.j=40;
		Demo.run();
		Demo d = new Demo();
		d.i=50;
		d.eat();
		
		
	}

}
