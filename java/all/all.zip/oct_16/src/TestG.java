
public class TestG {

	public static void main(String[] args) {
		Scientific s=new Scientific();
		s.cost=100;
		s.add();
		s.mul();
		s.sin();
		s.cos();
		
		
		
		Calc c=new Calc();
		c.add();
		c.mul();
	}

}
