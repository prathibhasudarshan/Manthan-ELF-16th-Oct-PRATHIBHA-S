
public class TestI {

	public static void main(String[] args) {
		Dog d=new Dog();
		d.eat();
		d.walk();
		System.out.println(" lion");
		Lion l=new Lion();
		l.eat();
		l.run();

	}

}
