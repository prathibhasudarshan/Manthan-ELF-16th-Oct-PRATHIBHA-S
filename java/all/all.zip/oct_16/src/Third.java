
public class Third extends Second
{
	void camera()
	{
		System.out.println(" i can take a pic");
	}

}
