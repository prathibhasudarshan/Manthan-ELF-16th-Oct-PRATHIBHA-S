
public class Van {
	int cost;
	String model;
	void move()
	{
		System.out.println("moving");
	}
	void stop()
	{
		System.out.println("walking");
	}

}
