
public class A 
{
	int i=90;
	

}
