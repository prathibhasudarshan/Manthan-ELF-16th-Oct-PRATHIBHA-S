
public class Animal
{
	Animal(int i)
	{
		//System.out.println("i");
	}

}
