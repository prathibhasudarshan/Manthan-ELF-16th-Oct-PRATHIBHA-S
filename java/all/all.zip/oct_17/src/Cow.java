
public class Cow 
{
	Cow()
	{
		//this(5);
		System.out.println("l");
	}
	
	Cow(int i)
	{
		this(2.4);
		System.out.println("p");
	}
	
	Cow(double j)
	{this();
		System.out.println("t");
	}

}
