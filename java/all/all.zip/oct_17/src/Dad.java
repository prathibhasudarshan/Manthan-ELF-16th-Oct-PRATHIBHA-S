
public class Dad 
{
	void bike()
	{
		System.out.println();
	}

}