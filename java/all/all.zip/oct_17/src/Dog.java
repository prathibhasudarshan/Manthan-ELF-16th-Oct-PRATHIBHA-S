
public class Dog extends Animal
{
	Dog()
	{
		super(5);
	}
	
	Dog(String n)
	{
		super(7);
	}
}
