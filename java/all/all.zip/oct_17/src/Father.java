
public class Father
{
	void home()
	{
		System.out.println(" has a big home");
	}

}
