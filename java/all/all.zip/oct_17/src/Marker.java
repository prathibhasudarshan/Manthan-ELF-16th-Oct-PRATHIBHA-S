
public class Marker extends Pen
{
	Marker()
	{
		this(2);
		
		System.out.println(" i m marker con");
		
	}
	
	Marker(int x)
	{
		super(5);
		//new Pen(7);
		System.out.println("n");
	}

}
