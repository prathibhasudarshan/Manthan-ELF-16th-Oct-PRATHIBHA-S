
public class Mouse
{
	 Mouse()
	{
	
	}
}
