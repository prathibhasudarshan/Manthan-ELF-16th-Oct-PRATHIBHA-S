
public class Pen
{
	Pen()
	{
		System.out.println("a is the output");
	}
	
	Pen(int q)
	{
		System.out.println("m");
	}

}
