
public class Son extends Father
{
	void gf()
	{
		System.out.println(" son has a gf");
	}

}
