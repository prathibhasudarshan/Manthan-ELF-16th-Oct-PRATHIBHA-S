
public class Student
{
	String name;
	int id;
	double per;
	
	
	
	
	public Student(String name, int id, double per) {
		this.name = name;
		this.id = id;
		this.per = per;
	}
	Student()
	{
		
	}
	void disp()
	{
		System.out.println(id+"  is the id");
		System.out.println(name+"  is the id");
		System.out.println(per+"  is the id");
		
	}

}
