
public class TestA {

	public static void main(String[] args) {
		Father f = new Father();
		f.home();
		Son s = new Son();
		s.gf();
		s.home();
		/*Son o=new Father();
		o.gf();*/
		
	}

}
