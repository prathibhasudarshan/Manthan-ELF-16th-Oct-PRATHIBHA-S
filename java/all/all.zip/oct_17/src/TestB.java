
public class TestB {

	public static void main(String[] args) {
		Van v = new Van();
		Van b = new Van(5);
		new Van(6,8);
		new Van(9.7);
		v.add();
		b.add();
	}

}
