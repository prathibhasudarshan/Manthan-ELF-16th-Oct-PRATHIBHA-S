
public class TestC {

	public static void main(String[] args) {
		Student s = new Student("pppp", 77, 98.3);
		s.disp();
		
		System.out.println("---------------");
		Student s1 = new Student();
		s1.disp();
		
		

	}

}

