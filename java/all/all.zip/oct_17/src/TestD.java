
public class TestD {

	public static void main(String[] args) {
		new Marker();
		//new Pen();
		
		//new Marker(5);
	}

}
