
public class TestE {

	public static void main(String[] args) {
		new Cow(2.8);
		new Cow(4);
		
	}

}
