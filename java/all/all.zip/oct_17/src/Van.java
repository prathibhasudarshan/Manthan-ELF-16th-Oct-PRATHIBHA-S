
public class Van
{
	Van()
	{
		System.out.println(" i m zero parameterized");
	}
	Van(int a)
	{
		System.out.println(" i m int parameterized");
	}
	Van(int a,int b)
	{
		System.out.println(" i m int,int parameterized");
	}
	Van(double a)
	{
		System.out.println(" i m double parameterized");
	}
	
	void add()
	{
		System.out.println("add");
	}

}
