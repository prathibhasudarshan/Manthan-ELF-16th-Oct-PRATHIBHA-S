
public abstract class Animal 
{
	void drink()
	{
		System.out.println(" drink");
	}
	
	 abstract void eat();

}
