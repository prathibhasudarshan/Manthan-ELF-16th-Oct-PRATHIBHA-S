
public class Bike implements Cycle, Bus 
{

	@Override
	public void move() {
		Cycle.super.move();
	}

	
	

}
