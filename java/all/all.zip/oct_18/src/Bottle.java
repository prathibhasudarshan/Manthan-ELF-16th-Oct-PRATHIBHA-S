
public interface Bottle 
{
	void open();
	void close();
}
