
public interface Bus
{
	default void move()
	{
		System.out.println(" bus");
	}

}
