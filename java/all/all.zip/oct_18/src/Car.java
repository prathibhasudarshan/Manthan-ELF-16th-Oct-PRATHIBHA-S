
abstract public class Car 
{
	void move()
	{
		
	}
	
	abstract void music();
	abstract void sunRoof();

}
