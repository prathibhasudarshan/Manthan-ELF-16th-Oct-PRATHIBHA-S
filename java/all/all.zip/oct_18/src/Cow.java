
public class Cow extends Animal {

	@Override
	void eat() {
		System.out.println(" cow grazes and eat");
	}

}
