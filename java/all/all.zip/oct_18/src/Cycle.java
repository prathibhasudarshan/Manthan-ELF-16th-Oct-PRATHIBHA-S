
public interface Cycle

{
	default void move()
	{
		System.out.println(" my cycle");
	}

}
