
public class Fanta implements Bottle {

	@Override
	public void open() {
System.out.println(" fanta is open ");		
	}

	@Override
	public void close() {
System.out.println(" fanta is close");		
	}

}
