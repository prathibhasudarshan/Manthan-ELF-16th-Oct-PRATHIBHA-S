
public class Hero extends Honda 
{
	void design()
	{
		System.out.println("design");
	}
	
	void color()
	{
		System.out.println(" black");
	}
	
	void engine()
	{
		System.out.println(" engineee");
	}

}
