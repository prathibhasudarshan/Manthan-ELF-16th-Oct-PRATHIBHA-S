
abstract public class Honda {
	void engine()
	{
		System.out.println("this is engine");
	}
	
	void run()
	{
		System.out.println("runs");
	}
	abstract void design();
	abstract void color();
}
