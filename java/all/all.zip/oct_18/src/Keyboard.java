
public interface Keyboard {
	void press();
}
