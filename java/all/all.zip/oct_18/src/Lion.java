
public class Lion extends Animal {

	@Override
	void eat() {
		System.out.println(" lion is eating");
	}

}
