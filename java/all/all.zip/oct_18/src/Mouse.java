
public interface Mouse {
	void click();
}
