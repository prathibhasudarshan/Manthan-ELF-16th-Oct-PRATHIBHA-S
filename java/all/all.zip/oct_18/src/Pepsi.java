
public class Pepsi implements Bottle {

	@Override
	public void open() {
System.out.println(" pepsi is open");		
	}

	@Override
	public void close() {
System.out.println(" pepsi is close");		
	}
	

}
