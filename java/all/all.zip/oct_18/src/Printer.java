
public interface Printer 
{
	void print();

}
