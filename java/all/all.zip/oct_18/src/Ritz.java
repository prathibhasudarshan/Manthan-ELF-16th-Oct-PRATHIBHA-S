
public class Ritz extends Car {

	@Override
	void sunRoof() {
		System.out.println("i m sunroof");		
	}
	
	void music() {
		System.out.println(" i m musicccccc");
		
	}


}
