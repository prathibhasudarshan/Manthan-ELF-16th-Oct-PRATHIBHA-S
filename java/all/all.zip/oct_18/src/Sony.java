
public class Sony implements Printer {
	public void print()
	{
		System.out.println(" printing");
	}

}
