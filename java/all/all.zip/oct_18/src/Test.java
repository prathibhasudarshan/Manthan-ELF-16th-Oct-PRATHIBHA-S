final interface A
{
	void m();
	
	                                               
}
public class Test {

}
