
public class TestA {
	public static void main(String[] args) {
		Honda a=new Hero();
		a.design();
		a.color();
		a.engine();
		a.run();
	}

}
