
public class TestB {

	public static void main(String[] args) {
		Car c = new Ritz();	
		c.move();
		c.music();
		c.sunRoof();
	}
}
