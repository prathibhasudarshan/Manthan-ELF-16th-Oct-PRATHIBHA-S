
public class TestC {

	public static void main(String[] args) {
		Lion l=new Lion();
		l.drink();
		l.eat();
		Cow c=new Cow();
		c.drink();c.eat();
		Animal a=new Cow();
		a.drink();
		a.eat();
		
	}

}
