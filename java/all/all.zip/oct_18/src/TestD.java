
public class TestD {

	public static void main(String[] args) {
		Sony s=new Sony();
		s.print();
	}

}
