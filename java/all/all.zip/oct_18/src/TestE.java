
public class TestE {

	public static void main(String[] args) {
		Fanta f=new Fanta();
		f.close();
		f.open();
		Pepsi p=new Pepsi();
		p.close();
		p.open();
	}

}

