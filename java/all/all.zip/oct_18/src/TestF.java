
public class TestF {

	public static void main(String[] args) {
		Bike b = new Bike();
		b.move();
		
		
		
	}

}
