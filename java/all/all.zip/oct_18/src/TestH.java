
public class TestH {

	public static void main(String[] args) {
		Touch t = new Touch();
		t.click();
		t.press();
		
		
		Mouse m = new Touch();
		m.click();
		
		Keyboard k = new Touch();
		k.press();       
	}

}
