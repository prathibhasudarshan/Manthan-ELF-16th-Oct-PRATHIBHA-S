
public abstract  class Zen extends Car{
	@Override
	void music() {
		System.out.println(" i m music");
		
	}

}
