package com.testyantra.student.jspiders;

public class Angular 
{
	public void teachAngular()
	{
		System.out.println(" i m teach in angular");
	}

}
