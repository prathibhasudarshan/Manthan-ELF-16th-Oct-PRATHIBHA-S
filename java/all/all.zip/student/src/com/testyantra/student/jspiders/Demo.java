package com.testyantra.student.jspiders;

public class Demo
{
	public static int cost=2;
	void eat()
	{
		System.out.println(" i m eating");
	}
	
	
	public static void run()
	{
		System.out.println(" i m runnuing");
	}
}
