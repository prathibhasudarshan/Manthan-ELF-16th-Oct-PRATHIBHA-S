package com.testyantra.student.jspiders;

public class React {
	public void teachReact()
	{
		System.out.println(" i m teach in react");
	}

}
