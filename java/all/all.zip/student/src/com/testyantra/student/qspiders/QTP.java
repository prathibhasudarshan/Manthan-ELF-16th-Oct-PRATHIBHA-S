package com.testyantra.student.qspiders;

public class QTP {
	public void teachQTP()
	{
		System.out.println(" i m teach in QTP");
	}
}
