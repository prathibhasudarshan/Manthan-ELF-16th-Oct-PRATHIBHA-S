package com.testyantra.student.qspiders;

public class Selenium {
	public void teachSelenium()
	{
		System.out.println(" i m teach in selenium");
	}

}
