package com.testyantra.student.qspiders;

import com.testyantra.student.jspiders.Demo
;
import static com.testyantra.student.jspiders.Demo.*;
public class TestC {

	public static void main(String[] args) 
	{
		Demo d=new Demo();
		System.out.println(d.cost);
		
		run();
	}

}
